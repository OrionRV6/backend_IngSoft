// src/db.js
require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

// Opcional: log para saber que la conexión se creó
pool.on('connect', () => {
  console.log('✅ Conectado a PostgreSQL');
});

module.exports = pool;